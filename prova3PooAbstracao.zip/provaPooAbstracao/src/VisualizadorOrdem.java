import java.util.ArrayList;

public interface VisualizadorOrdem {
    String verOrdens();
}

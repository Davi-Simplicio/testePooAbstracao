public interface EditorOrdem {
    String editarOrdem(int numeroOrdem, OrdemDeServico ordem);
}

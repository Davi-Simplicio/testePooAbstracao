public interface CriadorOrdem {
    String criarOrdem(OrdemDeServico ordem);
}

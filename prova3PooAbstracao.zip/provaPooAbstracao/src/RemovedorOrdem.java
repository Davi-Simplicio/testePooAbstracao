public interface RemovedorOrdem {
    String deletarOrdem(int numeroOrdem);
}

public interface Imprimivel {
    String mostrarDados();
}
